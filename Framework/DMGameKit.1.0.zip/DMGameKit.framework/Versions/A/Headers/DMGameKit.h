//
//  DMGameKit.h
//  DMGameKit
//
//  Created by Master on 2015/03/13.
//  Copyright (c) 2015年 net.masuhara. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DMGameKit : NSObject

- (void) startLogic;

@end
